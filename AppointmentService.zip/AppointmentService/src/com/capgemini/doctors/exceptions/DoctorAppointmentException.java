package com.capgemini.doctors.exceptions;

public class DoctorAppointmentException extends Exception {
	public DoctorAppointmentException(String msg)
	{
		super(msg);
	}
}
