package com.capgemini.doctors.dao;

public interface IQueryMapper {
	public static final String INSERT_QUERY="INSERT INTO doctor_appointment values(seq_appointment_id.nextval,?,?,?,?,?,?,?,?,?)";
	public static final String GET_AID="SELECT seq_appointment_id.CURRVAL FROM DUAL";
	public static final String GET_STATUS= "select PATIENT_NAME,APPOINTMENT_STATUS,DOCTOR_NAME,date_of_appointment from doctor_appointment where appointment_id = ?";
}
