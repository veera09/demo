package com.cg.exceptions;

public class LoanExceptions extends Exception{
	public  LoanExceptions (String msg){
		super(msg);
	}
}