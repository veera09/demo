package com.cg.bean;

public class LoanDto {
 private long loanId;
 private double loanAmount;
 private long cusId;
 private int duration;
public long getLoanId() {
	return loanId;
}
public void setLoanId(long loanId) {
	this.loanId = loanId;
}
public double getLoanAmount() {
	return loanAmount;
}
public void setLoanAmount(double loanAmount) {
	this.loanAmount = loanAmount;
}
public long getCusId() {
	return cusId;
}
public void setCusId(long cusId) {
	this.cusId = cusId;
}
public int getDuration() {
	return duration;
}
public void setDuration(int duration) {
	this.duration = duration;
}
}
