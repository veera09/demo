package com.cg.bean;

public class CustomerDto {
 private long cusId;
 private String cusName;
 private String address;
 private String mobile;
 private String email;
public long getCusId() {
	return cusId;
}
public void setCusId(long cusId) {
	this.cusId = cusId;
}
public String getCusName() {
	return cusName;
}
public void setCusName(String cusName) {
	this.cusName = cusName;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getMobile() {
	return mobile;
}
public void setMobile(String phno) {
	this.mobile = phno;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
}
