package com.cg.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.exceptions.LoanExceptions;


public class DBConnection {
	private static Connection con = null;
	/********************************
	 Method name : getConnection()
	 Input Parameter:
	 return type :DBConnection Instance
	 Description:Return dB instance
	 *
	 */

	public static Connection getConnection() throws LoanExceptions{ 
		if(con == null) {
		try {
			FileInputStream fis = new FileInputStream("Resources/jdbc.properties");
			Properties pro = new Properties();
			pro.load(fis);
			
			String driver = pro.getProperty("driver");
			String dburl = pro.getProperty("dbURL");
			String user = pro.getProperty("username");
			String pass = pro.getProperty("password");
			Class.forName(driver);
			con = DriverManager.getConnection(dburl,user,pass);
		} catch (FileNotFoundException fe) {
			throw new LoanExceptions("unable to find file properties file."+fe.getMessage());
		} catch (IOException ie) {
			throw new LoanExceptions("Problem occured while reading properties"+ie.getMessage());
		} catch (ClassNotFoundException ce) {
			throw new LoanExceptions("Driver class not found."+ce.getMessage());
		} catch (SQLException se) {
			throw new LoanExceptions("SQL Exception."+se.getMessage());
		}
		
		}
		return con;
	}
}