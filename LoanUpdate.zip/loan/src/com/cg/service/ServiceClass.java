package com.cg.service;

import java.sql.SQLException;
import java.util.regex.Pattern;

import com.cg.bean.CustomerDto;
import com.cg.bean.LoanDto;
import com.cg.dao.LoanDao;
import com.cg.exceptions.LoanExceptions;

public class ServiceClass implements IServiceClass{
	LoanDao a1 = new LoanDao();
	LoanDto loan = new LoanDto();
	@Override
	public boolean ValidateCustomerName(String custName) {
		// TODO Auto-generated method stub
		String namePattern = "[A-Z][a-z]{1,19}";
		if(Pattern.matches(namePattern,custName))
			return true;
		return false;
	}

	@Override
	public boolean ValidateMailId(String cusmailId) {
		// TODO Auto-generated method stub
		String mailIdPattern = "[A-Za-z0-9]{1,20}[@][A-Za-z]{3,15}[.][A-Za-z]{1,15}";
		if(Pattern.matches(mailIdPattern,cusmailId))
			return true;
		return false;
	}

	@Override
	public boolean ValidatePhoneNumber(String phno) {
		// TODO Auto-generated method stub
		String mobilePattern = "[0-9]{10}";
		if(Pattern.matches(mobilePattern,phno))
			return true;
		return false;
	}

	@Override
	public boolean ValidateAddress(String cusAddrs) {
		// TODO Auto-generated method stub
		String namePattern = "[A-Z][a-z]{1,19}";
		if(Pattern.matches(namePattern,cusAddrs))
			return true;
		return false;
	}
	public CustomerDto InsertCust(CustomerDto c1) throws LoanExceptions{
		return a1.InsertCust(c1);
	}
	public int getloanID() throws LoanExceptions, SQLException {
             return a1.getloanID();
}
	
	
	public LoanDto applyLoan(LoanDto loan) throws LoanExceptions {
return a1.applyLoan(loan);
}
}