package com.capgemini.doctors.service;

import java.time.LocalDate;
import java.util.List;

import com.capgemini.doctors.Exception.DoctorAppointmentException;
import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;
import com.capgemini.doctors.dao.IDoctorAppointmentDao;

public class DoctorAppointmentService implements IDoctorAppointmentService {
	IDoctorAppointmentDao dao=new DoctorAppointmentDao();

	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorappointment) throws DoctorAppointmentException {
		// TODO Auto-generated method stub
		return dao.addDoctorAppointmentDetails(doctorappointment);
	}

	@Override
	public DoctorAppointment getDoctorAppointmentDetails(int appointmentId) throws DoctorAppointmentException {
		// TODO Auto-generated method stub
		return dao.getAppointmentDetails(appointmentId);
	}
	public boolean validatePatient(DoctorAppointment doctorappointment) throws DoctorAppointmentException {
		if(!doctorappointment.getPatientName().matches("[A-Z][a-z]{2,20}")){
			throw new DoctorAppointmentException("Patient name Should start with capital letters");
		}
		if(!doctorappointment.getPhoneno().matches("[0-9]{10}")){
			throw new DoctorAppointmentException("Phone number should be of 10 digits");
		}
		if(!doctorappointment.getDateOfAppointment().isAfter(LocalDate.now())){
			throw new DoctorAppointmentException("Registration date should be before");
		}
		List<DoctorAppointment> dlist=(List<DoctorAppointment>) dao.getAppointmentDetails(doctorappointment.getAppointmentId());
		if(dlist.stream().filter(d->d.getAppointmentId()==doctorappointment.getAppointmentId()).count()==0)
		{
			throw new DoctorAppointmentException("Invalid Appointment ");
		}
			
		return true;
		
	
	}

}
