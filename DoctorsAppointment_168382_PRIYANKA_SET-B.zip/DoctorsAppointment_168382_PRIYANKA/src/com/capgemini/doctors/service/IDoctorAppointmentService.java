package com.capgemini.doctors.service;

import com.capgemini.doctors.Exception.DoctorAppointmentException;
import com.capgemini.doctors.bean.DoctorAppointment;

public interface IDoctorAppointmentService {
	int addDoctorAppointmentDetails(DoctorAppointment doctorappointment) throws DoctorAppointmentException;
	DoctorAppointment getDoctorAppointmentDetails(int appointmentId) throws DoctorAppointmentException;
	boolean validatePatient(DoctorAppointment doctorappointment)  throws DoctorAppointmentException;

}
