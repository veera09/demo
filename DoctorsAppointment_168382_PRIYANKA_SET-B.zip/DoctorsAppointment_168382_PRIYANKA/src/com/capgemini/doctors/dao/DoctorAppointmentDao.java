package com.capgemini.doctors.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.doctors.Exception.DoctorAppointmentException;
import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.util.DatabaseConnection;

public class DoctorAppointmentDao implements IDoctorAppointmentDao {
	Connection conn;
	//Method to create Sequence for appointment ID...
	private int generateAppointmentId() throws DoctorAppointmentException{
		String sql="SELECT seq_appointment_id.NEXTVAL FROM DUAL";
		conn=DatabaseConnection.getConnection();
		try{
			Statement st=conn.createStatement();
			ResultSet rs=st.executeQuery(sql);
			rs.next();
			return rs.getInt(1);
		}catch(SQLException e){
			throw new DoctorAppointmentException("Problem in generating Appointment ID"+e.getMessage());
		}
	}
	//Method to add patient appointment details into the table

	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorappointment)
			throws DoctorAppointmentException {
		// TODO Auto-generated method stub
		String sql="INSERT INTO doctor_appointment VALUES(?,?,?,?,?,?,?,?,?,?)";
		doctorappointment.setAppointmentId(generateAppointmentId());
		try{
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, doctorappointment.getAppointmentId());
			pst.setString(2, doctorappointment.getPatientName());
			pst.setString(3, doctorappointment.getPhoneno());
			pst.setDate(4, Date.valueOf(doctorappointment.getDateOfAppointment()));
			pst.setString(5, doctorappointment.getEmail());
			pst.setInt(6, doctorappointment.getAge());
			pst.setString(7, doctorappointment.getGender());
			pst.setString(8, doctorappointment.getProblemName());
			pst.setString(9, doctorappointment.getDoctorName());
			pst.setString(10, doctorappointment.getAppointmentStatus());
			pst.executeUpdate();
		}catch(SQLException e){
			throw new DoctorAppointmentException("Problem in inserting patient details"+e.getMessage());
		}
		return doctorappointment.getAppointmentId();
	}
	
//Method written to get the appointment details based on appointment ID.......
	@Override
	public List<DoctorAppointment> getAppointmentDetails(int appointmentId)
			throws DoctorAppointmentException {
		// TODO Auto-generated method stub
		List<DoctorAppointment> dlist=new ArrayList<DoctorAppointment>();
		//DoctorAppointment doctorappointment;
		String sql="SELECT patient_name,appointment_status,doctor_name,date_of_appointment FROM doctor_appointment where appointment_id=?";
		conn=DatabaseConnection.getConnection();
		try{
			PreparedStatement st=conn.prepareStatement(sql);
			st.setInt(1,appointmentId);
			ResultSet rs=st.executeQuery(sql);
		
			while(rs.next()){
				DoctorAppointment doctorappointment=new DoctorAppointment();
				doctorappointment.setPatientName(rs.getString("patient_name"));
				doctorappointment.setAppointmentStatus(rs.getString("appointment_status"));
				doctorappointment.setDoctorName(rs.getString("doctor_name"));
				doctorappointment.setDateOfAppointment(rs.getDate("date_of_appointment"));
				
			
			}
		}catch(SQLException e){
			throw new DoctorAppointmentException("Problem in getting the appointment details"+e.getMessage());
		}
		return dlist;
	}

}
