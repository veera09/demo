package com.capgemini.doctors.dao;

import com.capgemini.doctors.Exception.DoctorAppointmentException;
import com.capgemini.doctors.bean.DoctorAppointment;

public interface IDoctorAppointmentDao {
	//Declaring methods to be overridden by DoctorAppointmentDao class.....
	public int addDoctorAppointmentDetails(DoctorAppointment doctorappointment) throws DoctorAppointmentException;
	public DoctorAppointment getAppointmentDetails(int appointmentId) throws DoctorAppointmentException;

}
