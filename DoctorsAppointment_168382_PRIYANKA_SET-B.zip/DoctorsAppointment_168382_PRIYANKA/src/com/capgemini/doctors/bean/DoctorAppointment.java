package com.capgemini.doctors.bean;

import java.time.LocalDate;

public class DoctorAppointment {
	//Declaring Variables
	private int appointmentId;
	private String patientName;
	private String phoneno;
	private LocalDate dateOfAppointment;
	private String email;
	private int age;
	private String Gender;
	private String problemName;
	private String doctorName;
	private String appointmentStatus;
	
	//Generated getters and setters.......
	public int getAppointmentId() {
		return appointmentId;
	}
	public void setAppointmentId(int appointmentId) {
		this.appointmentId = appointmentId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	public LocalDate getDateOfAppointment() {
		return dateOfAppointment;
	}
	public void setDateOfAppointment(LocalDate dateOfAppointment) {
		this.dateOfAppointment = dateOfAppointment;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public String getProblemName() {
		return problemName;
	}
	public void setProblemName(String problemName) {
		this.problemName = problemName;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public String getAppointmentStatus() {
		return appointmentStatus;
	}
	public void setAppointmentStatus(String appointmentStatus) {
		this.appointmentStatus = appointmentStatus;
	}
	//Overrided toString method....
	@Override
	public String toString() {
		return "DoctorAppointment [appointmentId=" + appointmentId
				+ ", patientName=" + patientName + ", phoneno=" + phoneno
				+ ", dateOfAppointment=" + dateOfAppointment + ", email="
				+ email + ", Gender=" + Gender + ", problemName=" + problemName
				+ ", doctorName=" + doctorName + ", appointmentStatus="
				+ appointmentStatus + "]";
	}
	

}
