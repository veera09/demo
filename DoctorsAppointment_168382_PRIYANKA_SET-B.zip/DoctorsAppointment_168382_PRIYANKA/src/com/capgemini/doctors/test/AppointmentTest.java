package com.capgemini.doctors.test;

import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.Before;
import org.junit.Test;

import com.capgemini.doctors.Exception.DoctorAppointmentException;
import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;
import com.capgemini.doctors.dao.IDoctorAppointmentDao;
import com.capgemini.doctors.service.DoctorAppointmentService;
import com.capgemini.doctors.service.IDoctorAppointmentService;

public class AppointmentTest {
	IDoctorAppointmentDao dao;
	@Before
	public void beforeMethod(){
		dao=new DoctorAppointmentDao();
		
	}
	@Test
	public void testAddDoctorAppointmentDetails(){
		DoctorAppointment d=new DoctorAppointment();
		d.setPatientName("Mounika");
		d.setPhoneno("9010162650");
		d.setDateOfAppointment(LocalDate.of(2019, 01, 26));
		d.setEmail("mounika@gmail.com");
		d.setAge(22);
		d.setGender("F");
		d.setProblemName("Dermatology");
		d.setDoctorName("Kanika Kapoor");
		d.setAppointmentStatus("APPROVED");
		try{
			assertNotNull(dao.addDoctorAppointmentDetails(d));
		}catch(DoctorAppointmentException e){
			e.printStackTrace();
		}
		
	}
	@Test(expected=DoctorAppointmentException.class)
	public void testvalidate() throws DoctorAppointmentException {
		DoctorAppointment d=new DoctorAppointment();
		d.setPatientName("Mounika");
		d.setPhoneno("901016265");
		d.setDateOfAppointment(LocalDate.of(2019, 01, 26));
		d.setEmail("mounika@gmail.com");
		d.setAge(22);
		d.setGender("F");
		d.setProblemName("Dermatology");
		d.setDoctorName("Kanika Kapoor");
		d.setAppointmentStatus("APPROVED");
		IDoctorAppointmentService service=new DoctorAppointmentService();
		assertFalse(service.validatePatient(d));
	}

}
