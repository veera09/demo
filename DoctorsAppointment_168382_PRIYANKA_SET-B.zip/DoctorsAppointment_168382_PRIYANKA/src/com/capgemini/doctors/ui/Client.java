package com.capgemini.doctors.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import com.capgemini.doctors.Exception.DoctorAppointmentException;
import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.service.DoctorAppointmentService;
import com.capgemini.doctors.service.IDoctorAppointmentService;

public class Client {

	public static void main(String[] args) throws DoctorAppointmentException {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		IDoctorAppointmentService service=new DoctorAppointmentService();
		do{
			System.out.println("Menu");
			System.out.println("1.Book Doctor Appointment");
			System.out.println("2.View Doctor Appointment");
			System.out.println("3.Exit");
			System.out.println("Enter your choice");
			int choice=sc.nextInt();
			switch(choice){
			case 1:
				DoctorAppointment doctorappointment=new DoctorAppointment();
				System.out.println("Enter patient name");
				String pname=sc.next();
				doctorappointment.setPatientName(pname);
				System.out.println("Enter Phone Number");
				String phoneno=sc.next();
				doctorappointment.setPhoneno(phoneno);
				System.out.println("Enter Appointment Date(dd-MM-yyyy)");
				String appointmentDate=sc.next();
				DateTimeFormatter format=DateTimeFormatter.ofPattern("dd-MM-yyyy");
				LocalDate appointmentDate1=LocalDate.parse(appointmentDate,format);
				doctorappointment.setDateOfAppointment(appointmentDate1);
				System.out.println("Enter email id");
				String email=sc.next();
				doctorappointment.setEmail(email);
				System.out.println("Enter age");
				int age=sc.nextInt();
				doctorappointment.setAge(age);
				System.out.println("Enter gender");
				String gender=sc.next();
				doctorappointment.setGender(gender);
				System.out.println("Enter problem Name");
				String problemName=sc.next();
				doctorappointment.setProblemName(problemName);
				System.out.println("Enter Doctor Name");
				String doctorName=sc.next();
				doctorappointment.setDoctorName(doctorName);
				if((problemName=="Heart"&&doctorName=="Brijesh Kumar")||
					(problemName=="Gynecology"&&doctorName=="Sharda Singh")||
					(problemName=="Diabetes"&&doctorName=="Heena Khan")||
					(problemName=="ENT"&&doctorName=="Paras mal")||
					(problemName=="Bone"&&doctorName=="Renuka Kher")||
					(problemName=="Dermatology"&&doctorName=="Kanika Kapoor"))
				/*System.out.println("Enter Appointment Status");
				String status=sc.next();*/
					doctorappointment.setAppointmentStatus("APPROVED");
				else 
					doctorappointment.setAppointmentStatus("DISAPPROVED");
				try{
					if(service.validatePatient(doctorappointment)){
						service.addDoctorAppointmentDetails(doctorappointment);
						System.out.println("Registered Successfully with Appointment id : "+doctorappointment.getAppointmentId());
					}
				}catch(DoctorAppointmentException e){
					System.err.println(e.getMessage());
				}
				break;
			case 2:
				System.out.println("Enter your Appointment Id");
				int AppointmentId=sc.nextInt();
				List<DoctorAppointment> clist=(List<DoctorAppointment>) service.getDoctorAppointmentDetails(AppointmentId);
				if(clist.size()==0){
					System.out.println("No appoint available with the Appointment Id");
				}
				else{
					System.out.println("Patient Name\nAppointment Status\nDoctor Name\nAppointmentDate");
					clist.stream().forEach(System.out::println);
				}
				break;
			case 3:
				System.out.println("Thank You");
				System.exit(0);
				break;
			default:
				System.out.println("Invalid Choice....Try Again");
			}
		}while(true);

	}

}
