package com.capgemini.doctors.Exception;

public class DoctorAppointmentException extends Exception {
	public DoctorAppointmentException(){
		
	}
	public DoctorAppointmentException(String str){
		super(str);
	}

}
